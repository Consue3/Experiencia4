<div class="container-fluid">

<h1>Agregar Peliculas</h1>

<form method="POST" >
<div class="form-group">
Nombre:<input type="text" name="nombre" id="nombre" class="form-control"> <hr>
Raza:<input type="text" name="raza" id="raza" class="form-control"> <hr>
alimento<input type="text" name="alimento" id="alimento" class="form-control"> <hr>
Fechadenacimiento:<input type="date" name="fecha" id="fecha" class="form-control"> <hr>
	<button class="btn btn-primary">Aceptar</button>
</div>

</form>		








</div>