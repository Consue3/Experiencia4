

<div id="container">
	<h1> Mascotas </h1>
	<table class="table table-borderer">
		<thead>
				<th> Nombre</th>
				<th> Raza</th>
				<th> Alimento</th>
				<th> Fecha de nacimiento</th>
		</thead>
		<tbody>

				<?php foreach ($animal as $animals) { ?>
				<tr>
				<td><?php echo $animals->Nombre;?></td>
				<td><?php echo $animals->Raza; ?></td>
				<td><?php echo $animals->Alimento; ?></td>
				<td><?php echo $animals->Fechadenacimiento; ?></td>
				<td>
				
				</td>
				</tr>
				<?php } ?>
		</tbody>|	

</body>
</html>
