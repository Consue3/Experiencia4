<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class mascotas extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
    }
    
    
    public function obtener(){
        $query=$this->db->get("animal");
        return $query->result();

    }

    public function Anombre($id){
       $this->db->where('Nombre', $nombre);
        $query = $this->db->get('animal', 1);
        return $query->result();
    }
    public function editar($nombre,$alimento,$raza,$fechadenacimiento){
        $data=array(
            'nombre'=> $nombre,
            'alimento'=>$alimento,
            'raza'=>$raza,
            'fechadenacimiento'=>$fechadenacimiento
            );

    $this->db->where('Nombre', $nombre);
    return $this->db->update('animal',$data);
    }
}