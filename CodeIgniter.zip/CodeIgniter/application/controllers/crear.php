
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crear extends CI_Controller {

	

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('titulo');
		$this->load->view('agregar');
		$this->load->view('footer');
		
	}

}
?>
