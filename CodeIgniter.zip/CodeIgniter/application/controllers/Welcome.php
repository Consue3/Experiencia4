<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Mascotas');
		$this->load->helper('url');
	}
	public function index()
	{ 
		//$dato['string'] = 'hola weeii';
		$animal= $this->Mascotas->obtener();
		$data['animal']= $animal;
		$this->load->view('titulo',$data);
		$this->load->view('footer',$data);
		$this->load->view('welcome_message',$data);
			
	}
	public function eliminar($id){
		$this->Mascotas->eliminar($id);
		redirect('');
	}

	public function editarindex($id){
		$editable = $this->Mascotas->obtenerporid($id);
		$data['editable']=$editable[0];
		$this->load->helper('url');
		$this->load->view('header',$data);
		$this->load->view('editar',$data);
		$this->load->view('footer',$data);
	}

	public function editar(){
		$Nombre=$this->input->post('Nombre');
		$raza=$this->input->post('Raza');
		$Alimento=$this->input->post('Alimento');
		$FechadeNacimeinto=$this->input->post('FechadeNacimeinto');
		$this->Mascotas>editar($nombre,$raza,$Alimento, $FechadeNacimeinto);
		redirect('');
	}
}
